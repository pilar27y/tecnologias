# tecnologias
la gestión de la información representa un archivo importante en cualquier negocio.
